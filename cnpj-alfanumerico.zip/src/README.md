# CNPJ Alfanumérico

Este projeto oferece exemplos de cálculo de DV e métodos de validação de CNPJ alfanuméricos em diferentes linguagens de programação.

Para visualizar corretamente a página `index.html` execute o seguinte comando no diretório raiz:

**Usando Python 3:**

`python3 -m http.server`

A página estará disponível em [http://localhost:8000/index.html](http://localhost:8000/index.html)

**Usando Node:**

`npx http-server`

A página estará disponível em [http://localhost:8080/index.html](http://localhost:8080/index.html)
